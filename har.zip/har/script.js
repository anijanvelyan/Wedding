// Հետհաշվարկ (Նոյեմբերի 7, 2026)
const targetDate = new Date("November 7, 2026 11:00:00").getTime();

function updateCountdown() {
  const now = new Date().getTime();
  const diff = targetDate - now;

  if (diff > 0) {
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    document.getElementById("days").innerText = days;
    document.getElementById("hours").innerText = hours < 10 ? "0" + hours : hours;
    document.getElementById("minutes").innerText = minutes < 10 ? "0" + minutes : minutes;
    document.getElementById("seconds").innerText = seconds < 10 ? "0" + seconds : seconds;
  }
}

setInterval(updateCountdown, 1000);
updateCountdown();

// Ֆոնային երաժշտության նվագարկում
function toggleMusic() {
  const audio = document.getElementById("bg-music");
  const btn = document.getElementById("music-btn");

  if (audio.paused) {
    audio.play();
    btn.innerText = "⏸ Pause";
  } else {
    audio.pause();
    btn.innerText = "🎵 Play";
  }
}